import React from 'react';

function App() {
  return (
    <div>
      <h1>Welcome to TConnect 🚀</h1>
      <p>This is your social platform with Facebook + TikTok + YouTube features.</p>
    </div>
  );
}

export default App;
